# scenario/antennapatterns/SatAntennaGain_1

Описание директории `scenario/antennapatterns/SatAntennaGain_1`.

## Заметки пользователя
- ...

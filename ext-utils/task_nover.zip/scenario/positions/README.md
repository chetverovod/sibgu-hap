# scenario/positions

Описания положений узлов сцены.

## Базовые файлы
- `gw_positions.txt`
- `ut_positions.txt`
- `sat_positions.txt` или `tles.txt`
- `isls.txt` и `start_date.txt` (для созвездий, при необходимости)
- `sat_traces.txt` (для траекторий HAP)

## Формат строк координат
`Latitude Longitude Height`

## Дополнительно
Для `sat_traces.txt`: `satId traceFile`.
Для файлов трасс: `Time Latitude Longitude Altitude`.

## Заметки пользователя
- ...

# scenario/waveforms

Описание разрешенных waveforms для обратного канала.

## Обязательные файлы
- `waveforms.txt`
- `default_waveform.txt`

## Формат строки `waveforms.txt`
`ID ModBits CodingRate PayloadBytes DurationSymbols [PreambleSymbols]`

## Дополнительно
`default_waveform.txt` должен содержать один ID формы по умолчанию.

## Заметки пользователя
- ...
